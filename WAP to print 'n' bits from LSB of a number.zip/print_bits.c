/*
NAME-> Shubham Singh
DATE-> 13-6-22
DESCRIPTION->WAP to print 'n' bits from LSB of a number
Input->Enter the number: 10
Enter number of bits: 12
Output->Binary form of 10: 0 0 0 0 0 0 0 0 1 0 1 0 
*/

#include <stdio.h>

int print_bits(int, int);

int main()
{
    int num, n;
    
    printf("Enter num, n :\n");
    scanf("%d%d", &num, &n);
    
    printf("Binary form of %d:", num);
    print_bits(num, n);
 }
 
int print_bits(int num, int n)
{
    int val;
    for(int i = 0; i < n; i++)
    {
        if(num & ( 1 << ( (n-1) - i )))
        printf(" 1");
        else
        printf(" 0");
    }
}