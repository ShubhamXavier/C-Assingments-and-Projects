/*
NAME-> Shubham Singh
DATE-> 19-5-22
DESCRIPTION-> WAP to generate positive Fibonacci numbers
Input->Enter a number: 8
Output->0, 1, 1, 2, 3, 5, 8
*/

#include<stdio.h>
int main()
{
    int term, first, second, sum; 
    printf("Enter a number:");
    scanf("%d", &term);
    first = 0;
    second = 1;
    sum =0;
    if ( term >= 0)
    {
    for(int i=0; sum <= term; i++)    //runnig for loop to print the series as well to check the last of fibonacci series does not exceed with given term
    {
        printf("%d, ", sum);
        
        first = second;    //number swapping
        second = sum;     //number swapping
        sum = first + second;   //to get the fibonacci term
        
        
        
    }
   // printf("%d", sum);
    }
    else 
    printf("Invalid input");
    
}