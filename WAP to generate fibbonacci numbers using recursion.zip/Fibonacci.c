/*
NAME-> Shubham Singh
DATE-> 30-6-22
DESCRIPTION->WAP to generate fibbonacci numbers using recursion
Input->Enter a number: 8
Output->0, 1, 1, 2, 3, 5, 8

*/

#include <stdio.h>

void positive_fibonacci(int, int, int, int);

int main()
{
    int limit;
    
    printf("Enter the limit : ");
    scanf("%d", &limit);
    if(limit >= 0)
    {
        positive_fibonacci(limit, 0, 1, 0); //call of function
    }
    else
    {
        printf("Invalid input");
    }
    return 0;
}
void positive_fibonacci(int limit, int first, int second, int next)
{
    if(next <= limit)
    {
        printf("%d, ", next);  //print fibonacci
        first = second; //swap of first and second
        second = next;
        next = first + second;
        positive_fibonacci(limit, first, second, next); //call of function till next <= limit
    }
        
    
}