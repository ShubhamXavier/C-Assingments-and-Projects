/*
NAME-> Shubham Singh
DATE-> 30-6-22
DESCRIPTION->WAP to generate fibbonacci numbers using recursion
Input->Enter a number: 8
Output->0, 1, 1, 2, 3, 5, 8

*/

#include <stdio.h>

void negative_fibonacci(int, int, int, int);

int main()
{
    int limit;
    
    printf("Enter the limit : ");
    scanf("%d", &limit);
    limit *= -1; 
    if(limit >= 0)
    {
        negative_fibonacci(limit, 0, 1, 0); //call of function
    }
    else
    {
        printf("Invalid input");
    }
    return 0;
}
void negative_fibonacci(int limit, int first, int second, int next)
{
    static int count = 1;
    if(next <= limit)
    {
        if(count % 2 == 1)
        printf("%d, ", next * -1);  //print fibonacci
        else
        printf("%d, ", next); 
        count++;
        first = second; //swap of first and second
        second = next;
        next = first + second;
        negative_fibonacci(limit, first, second, next); //call of function till next <= limit
    }
        
    
}