/*
NAME-> Shubham Singh
DATE-> 4-6-22
DESCRIPTION-> WAP to count number of set bits in a given number and print parity
Input->Enter the number : 7
Output->Number of set bits = 3     Bit parity is Odd
*/

#include<stdio.h>
int main()
{
    int num, bit=1, set_bit=0 ;
    printf("Enter the number:");
    scanf("%d", &num);
    for( int i = 0 ; i <=31 ; i++)
    {
        if( num & bit )    //checking set bit here
        {
            set_bit += 1;    //increasing set_bit by one or used as a counter if bit of a given number is set.
        }
        bit = bit << 1;
        
    }
    
    printf("Number of set bits = %d \n", set_bit);
    if ( set_bit & 1 )   //checking if parity is even or odd
    {
      printf("Bit parity is Odd\n");  
    }
    else
    printf("Bit parity is Even\n");
    
    return 0;
    
}