/*
NAME-> Shubham Singh
DATE-> 8-8-22
DESCRIPTION->WAP to define a macro SIZEOF(x), without using sizeof operator
Input->
Output->
*/






#include<stdio.h>
#include<stdlib.h>


#define SIZEOF(x) (char *)(&x + 1) - (char *)(&x)     /*declaring sizeof macro*/
int main()
{
    int i;
    char c;
    float f;
    double le;
    uint ui;
    long int lle;
    
    printf("Size of int : %lu \n", SIZEOF(i));
    printf("Size of char : %lu \n", SIZEOF(c));
    printf("Size of float : %lu \n", SIZEOF(f));
    printf("Size of double : %lu \n", SIZEOF(le));
    printf("Size of unsigned int : %lu \n", SIZEOF(ui));
    printf("Size of long int : %lu \n", SIZEOF(lle));
    return 0;
}