/*
NAME-> Shubham Singh
DATE-> 27-7-22
DESCRIPTION->WAP to check given string is Pangram or not
Input->Enter the string: The quick brown fox jumps over the lazy dog
Output->The Entered String is a Pangram String

*/

#include<stdio.h>

int main()
{
char str[100];
printf("Enter the String:\n");
scanf("%[^\n]", str);
int i,value[26]={0},count=0;
for(i=0;str[i]!='\0';i++)
{
if('a'<=str[i] && str[i]<='z')
{
count+=!value[str[i]-'a'];
value[str[i]-'a']=1;
}
else if('A'<=str[i] && str[i]<='Z')
{
count+=!value[str[i]-'A'];
value[str[i]-'A']=1;
}
}
 if(count==26)
 {
  printf("The Entered String is a Pangram String");
 }
 else
 {
  printf("The Entered String is not a Pangram String");
 }

}
