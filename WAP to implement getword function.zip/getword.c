/*
NAME-> Shubham Singh
DATE-> 7-7-22
DESCRIPTION->WAP to implement getword function
Input->Enter the string : Welcome to Emertxe
You entered Welcome and the length is 7
*/

#include <stdio.h>

int getword(char *str);
int main()              
{   
    int len = 0;                
    char str[100];                            

    printf("Enter the string : ");  
    scanf(" %[^\n]", str);          
    len = getword(str);    
    printf("You entered %s and the length is %d\n    ", str, len);          
    }
    
    
int getword(char *str)
{
    int count = 0, i = 0;
    while( str[i] != ' ' && str[i++] != '\0' )     //will terminate the loop as soon as some space or null char arises
       count++; 
       
    i++;
    str[i] = '\0' ;  
    return count; 
        
}     