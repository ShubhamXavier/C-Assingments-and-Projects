#include <stdio.h>
#include <string.h>
#include <stdio_ext.h>

char *my_strtok(char * str, const char *delim);
unsigned int is_delim(char c, char *delim);

int main()
{
    char str[50], delim[50];
    
    printf("Enter the string  : ");
    scanf("%s", str);
    
    __fpurge(stdout);
 
    printf("Enter the delimeter : ");
    scanf("\n%s", delim);
    __fpurge(stdout);
    
    char *token = my_strtok(str, delim);
    printf("Tokens :\n");
    
    while (token)
    {
        printf("%s\n", token);
        token = my_strtok(NULL, delim);
    }
}

char *my_strtok(char * str, const char *delim)
{
   static char *backup_string; // start of the next search
    if(!str)
    {
        str = backup_string;
    }
    if(!str)
    {
            
        return NULL;
    } 
    
    while(1)
    {
        if(is_delim(*str, delim))
        {
            str++;
            continue;
        }
        if(*str == '\0')
        {
            // we've reached the end of the string
            return NULL; 
        }
        break;
    }
    
    char *ret = str;
    while(1)
    {
        if(*str == '\0')
        {
            /*end of the input string and
            next exec will return NULL*/
            backup_string = str;
            return ret;
        }
        if(is_delim(*str, delim))
        {
            *str = '\0';
            backup_string = str + 1;
            return ret;
        }
        str++;
    }
}

unsigned int is_delim(char c, char *delim)
{
    while(*delim != '\0')
    {
        if(c == *delim)
            return 1;
        delim++;
    }
    return 0;
}