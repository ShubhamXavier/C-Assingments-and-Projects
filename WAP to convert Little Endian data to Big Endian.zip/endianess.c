/*
NAME-> Shubham Singh
DATE-> 3-8-22
DESCRIPTION->WAP to convert Little Endian data to Big Endian
Input->Enter the size: 2
Enter any number in Hexadecimal: ABCD
Output->After conversion CDAB
*/

#include<stdio.h>

void swap(int * , int);  //prototype of a function is declared
int main()
{
    int size,hexa;
    printf("Enter the size: ");
    scanf("%d", &size);
    printf("Enter any number in Hexadecimal: ");
    scanf("%x\n", &hexa);
    swap(&hexa, size);
    printf("After conversion %x", hexa);
    
}
void swap(int *hexa, int size)   //function to swap byte so that conversion can happen
{
    char *ptr = (char *)hexa;
    char temp;
    for(int i = 0; i < size ; i++)
    {
        temp = ptr[--size];
        ptr[size] = ptr[i];
        ptr[i] = temp;
        
        
    }
    
}
