/*
NAME-> Shubham Singh
DATE-> 24-6-22
DESCRIPTION->WAP to remove duplicate elements in a given array
Input->Enter the size: 5
Enter elements into the array: 5 1 3 1 5
Output->After removing duplicates: 5 1 3
*/

#include <stdio.h>

void fun(int *arr1, int size, int *arr2, int *new_size);

int main()
{
    int size ;
    printf("Enter the size:");   //takinf size of an array
    scanf("%d", &size);
    int array1[size], array2[size], new_size = 0 ;
    printf("Enter elements into the array:"); //declaring array by user input
    for(int i = 0 ; i < size ; i++)
    {
        scanf("%d", &array1[i]);
    }
    fun( array1 , size , array2 , &new_size);   //calling function 
    
    printf("After removing duplicates:");
    for(int i = 0 ; i <= new_size ; i++ ) //printing original array with no dulpicate
    {
        printf(" %d", array2[i]);
    }
    
}

void fun(int *arr1, int size, int *arr2, int *new_size)
{
    int flag;
    arr2[0] = arr1[0];    //storintg first element of array 1 to array 2
    for(int i = 1 ; i < size ; i++)   //comparinfg element for duplicate and storing original one to array2
    {
      for(int j = 0 ; j < i ; j++)
      {
          if( arr1[i] != arr1[j] )
             flag=1; 
          else
             { flag=0; 
               break;
             }
      }
      if( flag == 1)
       {
           *new_size += 1 ;
           arr2[*new_size] = arr1[i];
       }
    }
    
    
}
    
