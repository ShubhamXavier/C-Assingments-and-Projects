/*
NAME-> Shubham Singh
DATE-> 27-7-22
DESCRIPTION->WAP to print all possible combinations of given string.
Input->Enter a string: abc
Output->All possible combinations of given string :abc
acb
bca
bac
cab
cba



*/

#include<stdio.h> 
#include<string.h>
void swap(char *x, char *y);
void combination(char *a,int l,int r )
{
    int i;  
    
if (l == r)  
    printf("%s\n", a);  
else
{  
    for (i = l; i <= r; i++)  
    {  
        swap((a+l), (a+i));  
        combination(a, l+1, r);  
        swap((a+l), (a+i)); //abc
    }  
}  
}
void swap(char *x, char *y)  
{  
    char temp;  
    temp = *x;  
    *x = *y;  
    *y = temp;  
}  
int my_strlen(char*);

int main()

{
        char str[100];
        int n;
        int res;
        printf("Enter a string: ");
        scanf("%100[^\n]",str);    
        n = strlen(str);
            for (int i = 0; i < n; i++)
            {
                for (int j = (i+1); j < n; j++)
                {
                    if(str[j] == str[i] )
                {
                     printf("Error : Enter distinct characters");
                     return 1;
                }
                }
            }
        combination(str,0,n-1);                       
        return 0;
}
