/*
NAME-> Shubham Singh
DATE-> 1-7-22
DESCRIPTION->WAP to replace each string of one or more blanks by a single blank
Input->Enter the string with more spaces in between two words
Pointers     are               sharp     knives.
Output->Pointers are sharp knives.
*/

#include <stdio.h>

void replace_blank(char *);

int main()
{
    char str[100];
    
    //printf("Enter the string with more spaces in between two words\n");
    scanf("%[^\n]", str);
    
    replace_blank(str);
    
    printf("%s\n", str);
}

void replace_blank(char *str)
{
    int count = 0;
    for(int i = 0; str[i]; i++ )  //loop acces each element of string
    {
        if(str[i] != ' ')  //if not a spcae 
        str[count++] = str[i];
        else if( str[i] == ' ' &&  str[i+1] != ' ') //to remove multiple blank
        str[count++] = str[i];
    }   
    str[count] = '\0'; //assigning null char in the end
    
}