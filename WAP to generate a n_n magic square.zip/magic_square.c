/*
NAME-> Shubham Singh
DATE-> 3-8-22
DESCRIPTION->WAP to generate a n*n magic square
Input->Enter a number: 3
Output->
8      1      6
3      5      7
4      9      2

*/


#include<stdio.h>
#include<stdlib.h>

void magic_square(int **, int);

int main()
{
    int n;
    printf("Enter a number:");
    scanf("%d", &n);
    
    //Dynamic memory allocation for matrix
    if( n % 2 != 0)
    {
     int **a = calloc(n , sizeof(int *));
     for(int i = 0; i <= n; i++)
     {
         a[i] = calloc( n , sizeof(int));
     }
     magic_square(a, n); //function calling
    }
    else
    {
        //if number is not odd then error
        printf("Error : Please enter only positive odd numbers");
    }

    
}

void magic_square(int **magic, int order)
{
   int  i, j, k, p, q, mid;

    mid = order/2;

    for(i=0;i< order; i++)
    {
        for(j=0; j< order; j++)
        {
            magic[i][j]=0;
        }
    }

    k=mid;
    j=0;
    for(i=1; i<= order*order; i++)
    {
        magic[j][k] = i;
        p = j--;
        q = k++;

        if(j< 0)
        {
            j = order-1;
        }

        if(k>order-1)
        {
            k=0;
        }

        if(magic[j][k] != 0)
        {
            k = q;
            j = p+1;
        }
    }

    
    for(j=0;j< order;j++)
    {
        
        for(k=0; k< order; k++)
        {
            printf("%d\t", magic[j][k]);
        }
    
        printf("\n");
    }
    
    
}
