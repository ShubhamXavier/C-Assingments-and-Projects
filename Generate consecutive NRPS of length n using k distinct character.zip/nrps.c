/*
NAME-> Shubham Singh
DATE-> 27-7-22
DESCRIPTION->Generate consecutive NRPS of length n using k distinct character
Input->Enter the number characters C : 3
Enter the Length of the string N : 6
Enter 3 distinct characters : a b c
Output->Possible NRPS is abcbca

*/

#include <stdio.h>

void nrps(char *, int, int);

int main()
{
    int C,N;
    char str[30];
    //read the input from the user
    printf("Enter the number characters C");
    scanf("%d", &C);
    printf("Enter the Length of the string N");
    scanf("%d", &N);
    printf("Enter %d distinct characters", C);
    for (int i = 0; i < C; i++)
    {
          scanf("\n%c", &str[i]);
    }
    for (int i = 0; i < C; i++)
    {
        for (int j = (i+1); j < C; j++)
        {
            if(str[j] == str[i] )
            {
                printf("Error : Enter distinct characters");
                return 1;
            }
        }
    }
    
    nrps(str, C, N);
    
    
    //function call to pass input to the function
}
void nrps(char *str, int c, int n)
{
   int i, val = 0, count = 0;
    
    for (i = 0; i < n; i++)
    {
        if(i%c == 0 && i != 0)
		{
			val++;
		}
        printf("%c", *(str+((i+val)%c)));
    }
}

