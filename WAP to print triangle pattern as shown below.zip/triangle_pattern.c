/*
NAME-> Shubham Singh
DATE-> 21-5-22
DESCRIPTION-> WAP to print triangle pattern as shown below
Input->5
Output->
1 2 3 4 5
6       7
8    9
10 11
12
*/
#include<stdio.h>
int main()
{
    int num, count=1;
    //printf("Enter the number");
    scanf("%d", &num);
    for(int row = 1 ; row <= num ; row++) // for loop to excess rows in  pattern pyramid
    {
        for(int column = 1 ; column <= num ; column++) // for loop to excess column in  pattern pyramid
        {
            if ( row == 1 || column == 1 || (row + column) == (num + 1)  ) //if any of the condition given becomes true it will print count
                 printf("%d ", count++);
            else
            printf("  "); // for other false condition it will print space
        }
        printf(" \n");
    }
return 0;
    
}