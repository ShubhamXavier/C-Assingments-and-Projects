/*
NAME-> Shubham Singh
DATE-> 6-8-22
DESCRIPTION->WAP to find the product of given matrix.
Input->Enter number of rows : 3
Enter number of columns : 3
Enter values for 3 x 3 matrix :
1      2      3
1      2      3
1      2      3
Enter number of rows : 3
Enter number of columns : 3
Enter values for 3 x 3 matrix :

1      1     1
2      2     2
3      3     3
Output->Product of two matrix :
14      14      14
14      14      14
14      14      14
*/

 
#include <stdio.h>  
#include<stdlib.h> 
/* Main Function */  
int main()  
{ 
/* Declaring pointer for matrix multiplication.*/ 
int **ptr1, **ptr2, **ptr3; 

/* Declaring integer variables for row and columns of two matrices.*/  
int row1, col1, row2, col2; 

/* Declaring indexes. */  
int i, j, k; 

/* Request the user to input number of columns of the matrices.*/  

printf("Enter number of rows :"); 
scanf("%d", &row1);  
printf("Enter number of columns :"); 
scanf("%d", &col1); 
/* Allocating memory for  matrix rows. */ 
ptr1 = (int **) malloc(sizeof(int *) * row1);  
/* Allocating memory for the col of  matrices. */ 
for(i=0; i<row1; i++) 
 	ptr1[i] = (int *)malloc(sizeof(int) * col1); 
/* Request the user to input members of first matrix. */ 
printf("Enter values for 3 x 3 matrix \n");  
for(i=0; i< row1; i++) 
{ 
	for(j=0; j< col1; j++) 
	{ 
		
		scanf("%d", &ptr1[i][j]); 
	} 
}  	
 	
 	
 	
printf("Enter number of rows :"); 
scanf("%d", &row2); 
printf("Enter number of columns :"); 
scanf("%d", &col2); 
/* Allocating memory for matrix rows. */ 
ptr2 = (int **) malloc(sizeof(int *) * row2);
/* Allocating memory for the col of  matrices. */ 
for(i=0; i<row2; i++)  
 	ptr2[i] = (int *)malloc(sizeof(int) * col2);
 	
printf("Enter values for 3 x 3 matrix \n"); 
for(i=0; i< row2; i++) 
{ 
	for(j=0; j< col2; j++) 
	{ 
		 
		scanf("%d", &ptr2[i][j]); 
	} 
}  	
 	
if(col1 != row2) 
{ 
	printf("Matrix multiplication is not possible");  
	return(0);  
} 


/* Allocating memory for matrix rows resultant. */ 
ptr3 = (int **) malloc(sizeof(int *) * row1); 
/* Allocating memory for the col of matrices resultant. */ 
for(i=0; i<row1; i++)  
 	ptr3[i] = (int *)malloc(sizeof(int) * col2); 


/* Calculation begins for the resultant matrix. */ 
if(row1 == row2 && col1 == col2)
{
for(i=0; i < row1; i++) 
{ 
	for(j=0; j < col1; j++) 
	{ 
		ptr3[i][j] = 0; 
 		for(k=0; k<col2; k++)  
		ptr3[i][j] = ptr3[i][j] + ptr1[i][k] * ptr2[k][j]; 
	} 
} 

/* Printing the contents of third matrix. */  
printf("Product of two matrix :\n");  
for(i=0; i< row1; i++)  
{   
	for(j=0; j < col2; j++) 
	{
	printf("%d\t", ptr3[i][j]); 
	    
	} 
    printf("\n");
}
}
else
{
    for(i=0; i < row1; i++) 
{ 
	for(j=0; j < col1; j++) 
	{ 
		ptr3[i][j] = 0; 
 		for(k=0; k<=col2; k++)  
		ptr3[i][j] = ptr3[i][j] + ptr1[i][k] * ptr2[k][j]; 
	} 
} 

/* Printing the contents of third matrix. */  
printf("Product of two matrix :\n");  
for(i=0; i< row1; i++)  
{   
	for(j=0; j < col2; j++) 
	{
	printf("%d\t", ptr3[i][j]); 
	    
	} 
    printf("\n");
}
}
return 0; 
} 