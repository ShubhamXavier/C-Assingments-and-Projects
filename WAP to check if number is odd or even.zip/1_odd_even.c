/*
NAME-> Shubham Singh
DATE-> 19-5-22
DESCRIPTION-> WAP to check if number is odd or even
Input->Enter the value of 'n' : -2
Output->2 is positive even number
*/

#include<stdio.h>                                                                               
int main()
{   int n;
printf("Enter the value of 'n':");
scanf("%d", &n);
if ( n > 0 ) //to check if number is positive 
{ 
    if ( n%2 == 0 )  //to check if number is even or odd
    printf(" %d is positive even number", n);  
    else                                       
    printf(" %d is positive odd number", n); 
    
}  
else if ( n < 0 ) //to check if number is negative    
{    
        if ( n%2 == 0)    //to check if number is even or odd
        printf(" %d is negative even number", n);  
        else   
        printf(" %d is negative odd number", n);  
}    
else    
        printf("0 is neither odd nor even");   
        
return 0;                                                                                                                                                                                            
    
}           