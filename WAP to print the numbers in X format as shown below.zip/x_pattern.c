/*
NAME-> Shubham Singh
DATE-> 21-5-22
DESCRIPTION-> WAP to print the numbers in X format as shown below
Input->4
Output->
1  4
 23
 23
1  4
*/
#include<stdio.h>
int main()
{
    int num;
    printf("Enter the number:");
    scanf("%d", &num);
    for(int row = 1 ; row <= num ; row++) // for loop to excess rows in X pattern
    {
        for(int column = 1 ; column <= num ; column++) // for loop to excess column in X pattern
        {
            if (row == column) //when row an column are equal it will print either row or column value
            {
                 printf("%d", row);
            }
            else if ( (row + column) == (num + 1) ) //when row + column becomes equal to num + 1 then it will print column
            {
                printf("%d", column);
            }
            else
            printf(" "); // for other false condition it will print space
        }
    }
    
}