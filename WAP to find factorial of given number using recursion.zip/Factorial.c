/*
NAME-> Shubham Singh
DATE-> 21-6-22
DESCRIPTION->WAP to find factorial of given number using recursion
Input->Enter the value of N : 7
Output->Factorial of the given number is 5040

*/

#include <stdio.h>

int main()
{
    static int num;
    static unsigned long long int fact = 1;
    static int count=0;
    if(count == 0)  //using static count to take one time input from user
    {
        printf("Enter the value of N :");
        scanf("%d", &num);
        count++;
    }
    
    if(num < 0)
     printf("Invalid Input");
    else if(num <= 1)
     {
         printf("Factorial of the given number is %lld", fact);
         return 0;
     }
    else
     {
      fact = fact * num;   //calculating factorial
      num = num - 1;
      return main();
     }
     return 0;
}