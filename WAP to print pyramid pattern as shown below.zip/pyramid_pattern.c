/*
NAME-> Shubham Singh
DATE-> 21-5-22
DESCRIPTION-> WAP to print pyramid pattern as shown below
Input->5
Output->
5
4 5
3 4 5
2 3 4 5
1 2 3 4 5
2 3 4 5
3 4 5
4 5
5
*/
#include<stdio.h>
int main()
{
    int num;
    printf("Enter the number");
    scanf("%d", &num);
    for(int row = 1 ; row <= num ; row++) // for loop to excess rows in  pattern pyramid
    {
        
        for(int column = ( num - row + 1 ) ; column <= num ; column++) // for loop to excess column in  pattern pyramid
        {
                 printf("%d ", column);
        }
        printf(" \n");
    }
    for(int row = 1 ; row <= ( num - 1 ) ; row++) // for loop to excess rows in  pattern pyramid
    {
        for(int column = ( row + 1 ); column <= num ; column++) // for loop to excess column in  pattern pyramid
        {
                 printf("%d ", column);
        }
        printf(" \n");
    }
return 0;
    
}