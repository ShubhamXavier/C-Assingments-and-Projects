/*
NAME-> Shubham Singh
DATE-> 15-6-22
DESCRIPTION->WAP to implement your own islower() function
Input->Enter the character: a
Output->Entered character is lower case alphabet
*/

#include <stdio.h>

int my_islower(int);

int main()
{
    char ch;
    int ret;
    
    printf("Enter the character:");
    scanf("%c", &ch);
    
    ret = my_islower(ch);
    /*
        Based on return value, print whether ch is lower case alphabet or not
    */
}

int my_islower(int ch)
{
    //condirion to check if alphanumeric or not
    if( ch >= 97 && ch <= 122)
    printf("Entered character is lower case alphabet");
    else
    printf("Entered character is not lower case alphabet");
    
}