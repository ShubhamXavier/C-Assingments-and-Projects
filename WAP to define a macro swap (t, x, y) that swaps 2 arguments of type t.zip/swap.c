/*
NAME-> Shubham Singh
DATE-> 11-8-22
DESCRIPTION->WAP to define a macro swap (t, x, y) that swaps 2 arguments of type t
Input->Enter you choice : 1

Enter the num1 : 10
Enter the num2 : 20

Output->After Swapping :
num1 : 20
num2 : 10

*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//defining generic macro

#define SWAPG(t,x,y)                \
{                                   \
        t temp = x;                 \
        x = y;                      \
        y = temp ;                  \
                                    \
}         

//defining structure
struct array
{
    int a;
    char b;
    short c; 
    float d;
    double e; 
    char f[100];
};

int main()
{
    struct  array a1,a2;
    int choice;
    char t;
    char *ptr1, *ptr2;  //pointer to point strings
    char *array[6]= {"1. Int","2. char","3. short","4. float","5. double","6. string"};
    for(int i =0 ; i < 6; i++)
    {
        
       
        printf("%s\n", array[i]);
     
    }
    printf("Enter you choice :\n");
    scanf("%d", &choice);
    
   
    switch(choice)
    {
        case 1: printf("Enter the num1 :\n"); //swap int
                scanf("%d", &a1.a);
                printf("Enter the num2 :\n");
                scanf("%d", &a2.a);
                SWAPG(int, a1.a ,a2.a);
                printf("After Swapping :\n");
                printf("num 1: %d\n", a1.a);
                printf("num 2: %d\n", a2.a);
        break;
        case 2: getchar();                      //swap char
                printf("Enter the char1 :\n");
                scanf("%c", &a1.b);
                printf("Enter the char2 :\n");
                getchar();
                scanf("%c", &a2.b);
                SWAPG(char, a1.b, a2.b);
                printf("After Swapping :\n");
                printf("char 1: %c\n", a1.b);
                printf("char 2: %c\n", a2.b);
        break;
        case 3:  printf("Enter the num1 :\n"); //swap short
                 scanf("%hd", &a1.c);
                 printf("Enter the num2 :\n");
                 scanf("%hd", &a2.c);
                 SWAPG(short, a1.c, a2.c);
                 printf("After Swapping :\n");
                 printf("num 1: %hd\n", a1.c);
                 printf("num 2: %hd\n", a2.c);
        break;
        case 4: printf("Enter the num1 :\n"); //swap float
                scanf("%f", &a1.d);
                printf("Enter the num2 :\n");
                scanf("%f", &a2.d);
                printf("After Swapping :\n");
                SWAPG(float, a1.d, a2.d);
                printf("num 1: %f\n", a1.d);
                printf("num 2: %f\n",a2.d);
        break;
        case 5:  getchar();
                 printf("Enter the num1 :\n"); //swap double
                 scanf("%le", &a1.e);
                 printf("Enter the num2 :\n");
                 getchar();
                 scanf("%le", &a2.e);
                 printf("After Swapping :\n");
                 SWAPG(double, a1.e, a2.e);
                 printf("num 1: %le\n", a1.e);
                 printf("num 2: %le\n", a2.e);
        break;
        case 6:  getchar();
                 printf("Enter the string1 :\n"); //swap strings
                 scanf("%s", a1.f);
                 ptr1=a1.f;
                 printf("Enter the string2 :\n");
                 getchar();
                 scanf("%s", a2.f);
                 ptr2=a2.f;
                 SWAPG(char *, ptr1, ptr2);
                 printf("After Swapping :\n");
                 printf("string1: %s\n", a1.f);
                 printf("string2: %s\n", a2.f);
        break;
        default: printf("Enter right choice");
        break;
    }
    
    return 0;
}
