/*
NAME-> Shubham Singh
DATE-> 6-8-22
DESCRIPTION->Read n & n persEnter the size: 5
Input->
Enter the 5 names of length max 32 characters in each
[0] -> Delhi
[1] -> Agra
[2] -> Kolkata
[3] -> Bengaluru
[4] -> ChennaiEnter the size: 2

Output->The sorted names are:
Agra


Bengaluru
Chennai
Delhi
Kolkata
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void sortPersonNameASCII(char * array[], int personCount);
void swap_generic(void * aptr, void * bptr, int size);
int main()
{
    int nPerson, i, j, choice;
    int MAXLEN = 32;
    
    char **storenPerson;
    
    printf("Enter the size:");
    scanf("%d", &nPerson);
/*     if ((nPerson < 0) || (nPerson > MAXNAMES))
    {
        printf("Error: Size is Out of range. Retry\n");
        return 1;
    }
*/
     /* Memory to store n person Names */
    char ** const sptr = (char**)malloc(sizeof(char*) * nPerson);
    
    if (NULL == sptr)
    {
        printf("Error: Malloc allocation Failure \n");
        return 1;
    }
    
     /* Memory to save each names of maxlen 32*/
    for (i = 0; i < nPerson; i++)
    {
        sptr[i] = (char*)malloc(sizeof(char) * (MAXLEN+1));
        
        if (NULL == sptr[i]) {
            printf("Error: Malloc allocation Failure for Person [%d] \n", i);
            return 1;
        }

    }
    
     storenPerson = sptr;
     printf("Enter the %d names of length max 32 characters in each\n", nPerson);
    
    for (i = 0; i < nPerson; i++)
    {
        printf("[%d] -> ", i);
        scanf("%s", storenPerson[i]);
        
        /* check for names with maxlen 32 */
        if (strlen(storenPerson[i]) > MAXLEN) {
            printf("Error: name length of persdon %d is > 32. Retry\n", i);
            return 1;
        }
    }
 
     printf("The sorted names are:\n");
            sortPersonNameASCII(storenPerson, nPerson);
            
            for (i = 0; i < nPerson; i++)
            {
                printf("%s \n", storenPerson[i]);
            }
            
    free(sptr);
    storenPerson = NULL;
    
    printf("\n");
    return 0;
}

void sortPersonNameASCII(char * array[], int personCount)
{
    int i, j, MAXLEN =32;
    
    for (i = 0; i < personCount; i++)
    {
        for (j = 0; j < personCount - i - 1; j++)
        {
            if ((strcmp(*(array+j), *(array+j+1)) > 0 ))
            {
                swap_generic(*(array+j), *(array+j+1), MAXLEN);
            }
        }
    }
}

void swap_generic(void * aptr, void * bptr, int size)
{
    int i;
    char temp;
    
    for ( i = 0; i < size; i++ )
    {
        temp = * (char *) aptr;
        * (char *) aptr++ = * (char *) bptr;
        * (char *) bptr++ = temp;
    }
}

