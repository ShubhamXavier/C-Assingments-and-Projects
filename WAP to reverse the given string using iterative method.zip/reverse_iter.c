/*
NAME-> Shubham Singh
DATE-> 8-7-22
DESCRIPTION->WAP to reverse the given string using iterative method
Input->Enter the number : Enter a string : Hello World
Output->Reverse string is : dlroW olleH
*/



#include <stdio.h>
#include <string.h>

int length_1(char *str);
void reverse_iterative(char *str);

int main()
{
    char str[30];
    
    printf("Enter any string : ");
    scanf("%[^\n]", str);
    
    reverse_iterative(str);
    
    printf("Reversed string is %s\n", str);
}

void reverse_iterative(char *str)  //function for swap
{
   int length, c;
   char *begin, *end, temp;
 
   length = length_1(str);  //calling function to count length of a string
   begin  = str;
   end    = str;
 
   for (c = 0; c < length - 1; c++)
      end++;
 
   for (c = 0; c < length/2; c++)
   {        
      temp   = *end;
      *end   = *begin;
      *begin = temp;
 
      begin++;
      end--;
   }
}
int length_1(char *str)
{
   int count = 0;
 
   while( *(str + count) != '\0' )
      count++;
 
   return count;
}