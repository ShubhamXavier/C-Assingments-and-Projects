/*
NAME-> Shubham Singh
DATE-> 14-6-22
DESCRIPTION->WAP to implement Circular left shift
Input->Enter num: 12
Enter n : 3
Output-> 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0
*/

#include <stdio.h>

int circular_left(int, int);
int print_bits(int);

int main()
{
    int num, n, ret;
    
    printf("Enter the num:");
    scanf("%d", &num);
    
    printf("Enter n:");
    scanf("%d", &n);
    
    ret = circular_left(num, n);
    
    print_bits(ret);
}

int circular_left(int num, int n)
{
    int left;
    if(num >= 0)
    {
        for(int i = 0; i <= n; i++)
        {
            if(num & ( 1 << 31 ))
              {
                  num = num << 1;
                  num = num | 1;
              }
            else
            {
                num = num << 1;
            }
            
        }
    }
    else
    {
        for(int i = 0; i <= n; i++)
        {
            if(num & ( 1 << 31 ))
              {
                  num = num << 1;
                  num = num | 1;
                  num = num | (1 << 31);
              }
            
        }
        
    }
    return num;
    
}
int print_bits(int ret)
{
    printf("Result in Binary:");
    for(int i = 0; i < 32; i++)
    {
        if(ret & ( 1 << ( (32) - i )))
        printf(" 1");
        else
        printf(" 0");
    }
}

