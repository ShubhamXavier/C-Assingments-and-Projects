/*
NAME-> Shubham Singh
DATE-> 8-6-22
DESCRIPTION->WAP to get 'n' bits of a given number
Input->Enter the number: 10
Enter number of bits: 3
Output->Result = 2
*/

#include <stdio.h>

int get_nbits(int, int);

int main()
{
    int num, n, res = 0;
    
    printf("Enter num and n:");
    scanf("%d%d", &num, &n);
    
    res = get_nbits(num, n);
    
    printf("Result = %d\n", res);
}

int get_nbits( num1 , n1 )
{
    int res = 0;
    res = ( num1 ) & ( ( 1 << n1 ) -1);   // left shift 1 to nth position thne -1 to gt the desired bit then and operation to get bits
    return res;
    
}