/*
NAME-> Shubham Singh
DATE-> 20-5-22
DESCRIPTION-> WAP to generate negative Fibonacci numbers
Input->Enter a number: -8
Output->0, 1, -1, 2, -3, 5, -8
*/

#include<stdio.h>
int main()
{
    int term, term1, first, second, sum, sum1;
    printf("Enter a number:");
    scanf("%d", &term);
    first = 0;
    second = 1;
    sum =0;
    term1=term*-1;
    if ( term1 >= 0)
    {
    for(int i=1; sum <= term1 ; i++)    //runnig for loop to print the series as well to check the last of fibonacci series does not exceed with given term
    {
        if( i%2 == 1 )
         {
             sum1=sum*-1;
             printf("%d, ", sum1);
         }
        else
         {
             printf("%d, ", sum);
         }
        first = second;    //number swapping
        second = sum;     //number swapping
        sum = first + second;   //to get the fibonacci term
        
        
    }
    }
    else 
    printf("Invalid input");
return 0;    
    
}