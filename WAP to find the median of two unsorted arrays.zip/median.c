/*
NAME-> Shubham Singh
DATE-> 4-6-22
DESCRIPTION-> WAP to find the median of two unsorted arrays
Input->Enter the 'n' value for Array A: 5
       Enter the 'n' value for Array B: 5

Enter the elements one by one for Array A: 3 2 8 5 4
Enter the elements one by one for Array B: 12 3 7 8 5
Output->Median of array1 : 4
Median of array2 : 7
Median of both arrays : 5.5
*/

#include<stdio.h>
int main()
{
    int n1, n2, array1[50], array2[50], temp, mid1, mid2;
    float median1, median2, median3;
    printf("Enter the 'n' value for Array A:");
    scanf("%d", &n1);
    printf("Enter the 'n' value for Array B:");
    scanf("%d", &n2);
    
    printf("Enter the elements one by one for Array A:\n");
    for( int i = 0 ; i < n1 ; i++ )
    {
        scanf("%d", &array1[i]);
    }
    
    printf("Enter the elements one by one for Array B:\n");
    for( int i = 0 ; i < n2 ; i++ )
    {
        scanf("%d", &array2[i]);
    }
    
    //bubble sort both the arrays  array1
    
    for( int i = 0 ; i < n1  ; i++)
    {
        for (int j = 0 ; j < (n1 - i - 1) ; j++)
        {
            if( array1[j] > array1[j+1])
            {
                temp = array1[j];
                array1[j] = array1[j + 1];
                array1[j + 1] = temp;
            }
        }
    }
    
   //bubble sort for array2
   
   for( int i = 0 ; i < n2 ; i++)
    {
        for (int j = 0 ; j < (n2 - i - 1) ; j++)
        {
            if( array2[j] > array2[j+1])
            {
                temp = array2[j];
                array2[j] = array2[j + 1];
                array2[j + 1] = temp;
            }
        }
    }
   
   
   // finding median
   
   if(n1%2 ==0)
   {
       mid1=n1/2;
       mid2=(n1/2 - 1);
       median1=((float)array1[mid1] + array1[mid2])/2;
   }
   else
   {
       mid1=n1/2;
       median1=array1[mid1];
   }
   
   printf("Median of array1 : %g\n", median1);
   
   if(n2%2 == 0)
   {
       mid1=n2/2;
       mid2=(n2/2 - 1);
       median2=((float)array2[mid1] + array2[mid2])/2;
   }
   else
   {
       mid1=n2/2;
       median2=array2[mid1];
   }
   
   printf("Median of array2 : %g\n", median2);
   
   median3 = (median1 + median2)/2;
   printf("Median of both arrays : %g\n", median3);
    
    return 0;
    
    
    
}