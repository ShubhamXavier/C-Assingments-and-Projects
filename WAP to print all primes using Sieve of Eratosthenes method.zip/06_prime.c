
/*
NAME-> Shubham Singh
DATE-> 5-6-22
DESCRIPTION-> WAP to print all primes using Sieve of Eratosthenes method
Input->Enter the value of 'n' : 20
Output->The primes less than or equal to 20 are : 2, 3, 5, 7, 11, 13, 17, 19
*/

#include<stdio.h>
int main()
{
    int n, array[50], count=2, incre=0,  a;
    
    printf("Enter the value of 'n' :\n");
    scanf("%d", &n);
    if( n > 1 )
    {
    for( int i = 0 ; i < n-1 ; i++ )
    {
        array[i] = count;
        count++ ;
    }
    a=(n^(1/2));
    for(int i = 2 ; i <= a ; i++)
    {   ++incre;
        for( int j = incre ; j < n-1; j++ )
        {
            if( array[j] % i == 0)
            {
                array[j] = 0;
            }
        }
        
    }
    
    printf("The primes less than or equal to %d are : ", n);
    
    for(int i = 0 ; i < n-1 ; i++)
    {
        if( array[i] != 0 )
        {
            
            printf("%d, ", array[i] );
        }
    }
    }
    else  
    {
        printf("Please enter a positive number which is > 1");
    }
    
    
    return 0;
}