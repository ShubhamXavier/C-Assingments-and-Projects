/*
NAME-> Shubham Singh
DATE-> 21-5-22
DESCRIPTION-> WAP to find which day of the year
Input->Enter the value of 'n' : 5 4
Output-> The day is sunday
*/



#include<stdio.h>
int main()
{
    int n,first_day,case1,remainder;
    printf("Enter the value of 'n' :\n");
    scanf("%d", &n);
    if ( n >= 1 && n <= 365 )   // condition checking of n
    {
        printf("Choose First Day :\n");
        printf("1. Sunday\n");
        printf("2. Monday\n");
        printf("3. Tuesday\n");
        printf("4. Wednesday\n");
        printf("5. Thursday\n");
        printf("6. Friday\n");
        printf("7. Saturday\n");
        printf("Enter the option to set the first day : \n");
        scanf("%d", &first_day);
        if ( first_day <= 0 || first_day > 7 )    // condition checking of firstday
        {
            printf("Error: Invalid input, first day should be > 0 and <= 7\n");
        }
        else
        {
          remainder = n%7;   // getting remainder if n > 7
          if (remainder == 0)
          {
            case1 = first_day + n - 1 ;
          }
          else
          {
            case1 = first_day + remainder -1;
          }
          if ( case1 > 7 )
          { case1 = case1 % 7;}  // reducing case1 value under 7
          switch(case1)
          {
            case 1: printf("The day is Sunday\n");
            break;
            case 2: printf("The day is Monday\n");
            break;
            case 3: printf("The day is Tuesday\n");
            break;
            case 4: printf("The day is Wednesday\n");
            break;
            case 5: printf("The day is Thursday\n");
            break;
            case 6: printf("The day is Friday\n");
            break;
            case 7: printf("The day is Saturday\n");
            break;
            default: printf("Invalid\n");
            break;
          }
        }
    }
    else
    printf("Error: Invalid Input, n value should be > 0 and <= 365\n");
    
return 0;    
}