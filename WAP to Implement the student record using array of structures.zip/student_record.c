/*
NAME-> Shubham Singh
DATE-> 8-8-22
DESCRIPTION->WAP to define a macro SIZEOF(x), without using sizeof operator
Input->
Output->
*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//structure

struct Student
{
    char name[30];
    int rollno;
    struct Subject *sub;
    int total;
    int average;
    int totalSub;
};

struct Subject
{
    char subName[30];
    int marks;
    
};

struct Subject createStudentSubjectdata(struct Subject su)
{
       struct Subject *eachSubjectptr = &su;
       printf("Enter the sub name :");
       scanf("%s", eachSubjectptr -> subName);
       
       printf("Enter the Sub marks :");
       scanf("%d", &(*eachSubjectptr).marks);
       
       return su;
}

struct Student createStudentdata(struct Student s)
{
    int i;
    int sum;
    int totalSub;
     struct Student *studentptr = &s;
     int c;
     
     printf("Enter the  Student Roll No :");
     scanf("%d",  &s.rollno);
     
     printf("Enter the  Student name :");
     scanf("%s", studentptr -> name);
     
     printf("Enter the number of subjects :");
     scanf("%d", &totalSub);
     
     s.sub = (struct Subject *)malloc(totalSub * sizeof(struct Subject));
     
     if(NULL == s.sub)
     {
        printf("ERROR : malloc failed ");
        exit(1);
     }
     
     sum =0;
     for(i = 0; i < totalSub; i++)
     {
         (*((s.sub) + i)) = createStudentSubjectdata((*((s.sub)+i)));
         sum += ((*((s.sub)+i))).marks;
         
     }
     studentptr -> totalSub = totalSub;
     studentptr -> total = sum;
     studentptr -> average = (sum/totalSub);
     return s;
}

void displayStudentdata(struct Student s)
{
    struct Student *studentptr = &s;
    int i;
    
    printf("Student Roll no: %d \n", studentptr -> rollno);
    printf("Student name: %s \n", studentptr -> name);
    printf("Total Subjects : %d \n", studentptr -> totalSub);
    
    for(i = 0; i < studentptr -> totalSub; i++)
    {
        printf("Subject name %s: --> marks[%d] \n", ((s.sub)+i) -> subName, ((*((s.sub)+i))).marks);
        
    }
    printf("Total of marks : %d\n", s.total);
    printf("Average of marks : %d\n", s.average);
    if(s.average > 90)
     printf("Grade --> A\n");
    else if(s.average > 70 && s.average <=90)
     printf("Grade --> B\n");
    else if(s.average > 30 && s.average <=70)
     printf("Grade --> C\n");
    else if(s.average < 30)
     printf("Grade --> D\n");
    
    
}

int main()
{
    int choice,choice2, i;
    static int TotalStudents =0;
    static struct Student totalStu[10];
    char name[10]; 
    int rollno;
    char option, ch ;
    
   
    
        printf("No of students Dtabase to be created:\n");
        scanf("%d", &TotalStudents);
        
        for(i =0; i < TotalStudents; i++)
        {
            totalStu[i]= createStudentdata(totalStu[i]);
            
        }
        
    
    
        printf("Display Menu\n");
        printf("1. All student details\n");
        printf("2. Particular student details\n");
        printf("Enter your choice");
        scanf("%d",&choice);
        do{
        
        switch(choice)
        {
            case 1:  printf("All Student Details\n");
                     for(i =0; i < TotalStudents; i++)
                     {
                        displayStudentdata(totalStu[i]); 
                     }
                     break;
            case 2:  
                     printf("----Menu for Particular student---- \n1. Name.\n2. Roll no.\n");
                     scanf("%d", &choice2);
                     switch(choice2)
                     {
                     case 1: printf("\nPrintf Student name whose info has to be displayed :");
                             scanf("%s", name);
         
                             for(i =0; i < TotalStudents; i++)
                             {
                               if((strcmp(totalStu[i].name, name)) ==0)
                              {
                                displayStudentdata(totalStu[i]);
                                break;
                               }
                              }  
                             break;
                     case 2:
                     printf("\nPrintf Student rollno whose info has to be displayed :");
                     scanf("%d", &rollno);
         
                      for(i =0; i < TotalStudents; i++)
                      {
                           if(totalStu[i].rollno == rollno)                  
                           {
                              displayStudentdata(totalStu[i]);
                           }
                       } 
                       break;
                       
                     default: printf("enter right choice for name and roll  no");
                     break;
                     }
                     
                    
            default: break;
            
          
        }
        printf("Do you want to continue to display(Y/y): ");
        scanf("%c", &ch);
        
        }while( ch == 'y' || ch == 'Y');
        
       
        
      
return 0;
}
























