/*
NAME-> Shubham Singh
DATE-> 27-7-22
DESCRIPTION->Squeeze the character in s1 that matches any character in the string s2
Input->Enter s1 : Dennis Ritchie
Enter s2 : Linux
Output->After squeeze s1 : Des Rtche

*/

#include <stdio.h>
#include <ctype.h>

void squeeze (char *, char *);

int main ()
{
  char str1[30], str2[30];

  printf ("Enter string1:");
  scanf ("%[^\n]", str1);
  getchar();
  
  printf ("Enter string2:");
  scanf ("%[^\n]", str2);

  squeeze (str1, str2);

  printf ("After squeeze s1 : %s\n", str1);

}

void squeeze (char *s1, char *s2)
{
    int i,j,k;
    k=0;

    for(i=0;s1[i]!='\0';++i)
    {
        for(j=0; (s1[i]!=s2[j]) && s2[j]!='\0' ;++j)
            ;
        if(s2[j]=='\0')
            s1[k++] = s1[i];
    }
    
    s1[k]='\0';
}
