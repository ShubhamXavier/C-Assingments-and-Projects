/*
NAME-> Shubham Singh
DATE-> 24-5-22
DESCRIPTION-> WAP to generate AP, GP, HP series
Input->Enter the First Number 'A': 2
Enter the Common Difference / Ratio 'R': 3
Enter the number of terms 'N': 5
Output->AP = 2, 5, 8, 11, 14
GP = 2, 6, 18, 54, 162
HP = 0.5, 0.2, 0.125, 0.0909091, 0.0714285
*/



#include<stdio.h>
int main()
{
    int first_number, common_difference, terms, nth_term;
    float nth_term1;
    printf("Enter the First Number 'A':");
    scanf("%d", &first_number);
    printf("Enter the Common Difference / Ratio 'R':");
    scanf("%d", &common_difference);
    printf("Enter the number of terms 'N':");
    scanf("%d", &terms);
    if(terms > 1)
    {
        printf("AP = %d", first_number);
        nth_term=first_number;
        for(int i = 1; i < terms; i++)
        {
            nth_term = nth_term + common_difference;  //calculating ap nth term
        printf(", %d", nth_term);
        }
        printf("\n");
        
        printf("GP = %d", first_number);
        nth_term=first_number;
        for(int i = 1; i < terms; i++)
        {
            nth_term = nth_term * common_difference;  //calculating gp nth term
        printf(", %d", nth_term);
        }
        printf("\n");
        
        nth_term=first_number;
        nth_term1=first_number;
        printf("HP = %f", 1/nth_term1);
        for(int i = 1; i < terms; i++)
        {
            nth_term = nth_term + common_difference; // calculating ap nth term
            nth_term1 = (float) 1/nth_term;         //calculating hp nth term
            printf(", %f", nth_term1);
        }
        printf("\n");
    }
    else if(terms == 1)
    {
        printf("AP = %d,", first_number);
        printf("GP = %d,", first_number);
        nth_term1=first_number;
        printf("HP = %f,", 1/nth_term1);
    
    }
    else
    {
        printf("Invalid input\n");
    }
return 0;
    
}