/*
NAME-> Shubham Singh
DATE-> 15-6-22
DESCRIPTION->WAP to implement your own ispunct() function
Input->Enter the character: a
Output->WAP to implement your own ispunct() function
*/

#include <stdio.h>

int my_ispunct(int);

int main()
{
    char ch;
    int ret;
    
    printf("Enter the character:");
    scanf("%c", &ch);
    
    ret = my_ispunct(ch);
    /*
        Based on return value, print whether ch is lower case alphabet or not
    */
}
int my_ispunct(int ch)
{
    // condition to excluede all other character
    if(ch >= 48 && ch <= 57 || ch >= 65 && ch <= 90 || ch >= 97 && ch <= 122 || ch == 32 || ch == 9 || ch >= 0 && ch <= 31 || ch ==127  )
    printf("Entered character is not punctuation character");
    else
    printf("Entered character is punctuation character");
    
}