/*
NAME-> Shubham Singh
DATE-> 8-6-22
DESCRIPTION->WAP to replace 'n' bits of a given number
Input->Enter the number: 10
Enter number of bits: 3
Enter the value: 12
Enter number of bits: 3
Output->Result = 12
*/


#include <stdio.h>

int replace_nbits(int, int, int);

int main()
{
    int num, n, val, res = 0;
    
    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &val);
    
    res = replace_nbits(num, n, val);
    
    printf("Result = %d\n", res);
}

replace_nbits( num1 , n1 , val1 )
{
   int res = 0;
   res = ( (num1) & ( ~ ( ( 1 << n1 ) -1 ))) | ( val1 & ( ( 1 << n1) - 1 ));
   return res;
}