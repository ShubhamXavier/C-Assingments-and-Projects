/*
NAME-> Shubham Singh
DATE-> 4-6-22
DESCRIPTION->WAP to check N th bit is set or not, If yes, clear the M th bit
Input->Enter the number: 19

Enter 'N': 1

Enter 'M': 4
Output->Updated value of num is 3
*/

#include<stdio.h>
int main()
{
    int num, n ,m, flag=0;
    printf("Enter the number:");
    scanf("%d", &num);
    printf("Enter 'N':");
    scanf("%d", &n);
    printf("Enter 'M':");
    scanf("%d", &m);
    
    n = 1 << n  ; // left  shifting 1 to nth position
    
    if( num & n )    //check if bit is set or not
    {
        flag = 1;
    }
    else
    flag = 0;
    
    if( flag == 1 )   //if bit is set then clearing the bit
    {
        m = ~(1 << m ) ;
        num = num & m;
    }
    
    printf("Updated value of num is %d\n", num );
    
    return 0;
    
    
}