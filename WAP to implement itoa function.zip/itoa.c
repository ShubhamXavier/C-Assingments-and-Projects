/*
NAME-> Shubham Singh
DATE-> 7-7-22
DESCRIPTION->WAP to implement itoa function
Input->Enter the number : 1234
Output->Integer to string is 1234
*/

#include <stdio.h>

int itoa(int num, char *str);

int main()
{
    int num;
    char str[10];
    
    printf("Enter the number:");
    if(scanf("%d", &num))
     itoa(num, str);
    else
     str[0] = '0';
    
    printf("Integer to string is %s", str);
}

int itoa(int num, char *str)
{
    int isNegative = 0 ,i = 0, rem = 0, rev = 0, temp = num; // num 123
    char ch;
    if (num == 0)  //if num is zero output of string is zero
    {
        str[i++] = '0';
        str[i] = '\0';
    }
    
    if (num < 0)
    {
        isNegative = 1;
        num = -num;
    }
 
    temp = num;  // iF NUM IS 123
       { while(temp !=0)
         {
            rem = temp %10;
            rev = rev * 10 + rem;
            temp = temp/10;
         } //revrsing rev = 321
       }
    if (isNegative)  //if num is negative hten in string ading char - at the beginning
    {
        str[i++] = '-';
        str[i]   = '\0';
    }
    
    while(rev != 0)   //forming string from number reversed
    { 
        
        temp = rev % 10;
        rev = rev /10;// temp = 1
        ch = temp + 48;
        str[i] = ch;
        i++;
    }
    
    str[i] = '\0';
  
}

