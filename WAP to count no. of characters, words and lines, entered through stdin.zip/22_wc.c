/*
NAME-> Shubham Singh
DATE-> 30-6-22
DESCRIPTION->WAP to generate fibbonacci numbers using recursion
Input->Hello world
Dennis Ritchie
Linux
Output->Character count : 33
Line count : 3
Word count : 5
*/

#include<stdio.h>
int main()
{
    char ch; 
    int line_count = 0, char_count = 0, word_count = 0, count = 0 ; 
    while( (ch = getchar()) != EOF )
    {
        
        char_count++;
        if(ch == ' ' || ch == '\t')
        {
            count = 0;
        }
        
        else if( ch == '\n')
        {
            line_count++;
            count = 0;
        }
        if( count == 0)
        {
            
              word_count++;
           
        }
        count = 1;
    }
    
    printf("Character count : %d\n", char_count );
    printf("Line count : %d\n", line_count);
    printf("Word count : %d\n", word_count);
    
    return 0;
    
    
}