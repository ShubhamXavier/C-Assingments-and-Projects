/*
NAME-> Shubham Singh
DATE-> 15-6-22
DESCRIPTION->WAP to implement your own isblank() function
Input->Enter the character: a
Output->The character 'a' is not a blank character.
*/

#include <stdio.h>

int my_isblank(int);

int main()
{
    char ch;
    int ret;
    
    printf("Enter the character:");
    scanf("%c", &ch);
    
    ret = my_isblank(ch);
    /*
        Based on return value, print whether ch is blank character or not
    */
}

int my_isblank(int ch)
{
    ////condirion to check if blank character  or not
    if( ch == 32 || ch == 9)
    {
        printf("Entered character is a blank character");
    }
    else
    {
        printf("Entered character is not blank character");
    }
}