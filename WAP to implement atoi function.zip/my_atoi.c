/*
NAME-> Shubham Singh
DATE-> 7-7-22
DESCRIPTION->WAP to implement atoi function
Input->Enter a numeric string: 12345
String to integer is 12345

*/

#include <stdio.h>

int my_atoi(const char *);

int main()
{
    char str[20];
    
    printf("Enter a numeric string : ");
    scanf("%s", str);
    
    printf("String to integer is %d\n", my_atoi(str));
}

int my_atoi(const char * str)
{
    int temp = 0, num = 0, sign = 1;
    if( str[0] == '-') // for including - sign
    {
        sign = -1;
    }
    while( *str != '\0')
    {
        if(str[0] >= 'a' && str[0] <= 'z' || str[0] == '*')
          return 0;
        if(*str == '-'  || *str =='+') // starting string from index 1
        {
            str++;
        }
        if(*str == '-' || *str == '+')   // if more than one sign occur
        {
            return num;
        }
        temp = *str;    //converting string to integer
        temp -= 48;
        num = num * 10 + temp;
        str++;
        if(*str >= 'a' && *str <= 'z')    
        {
            return num *sign;
        }
    }
    return num *sign;
}
