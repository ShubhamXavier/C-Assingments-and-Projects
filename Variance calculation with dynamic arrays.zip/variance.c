/*
NAME-> Shubham Singh
DATE-> 3-8-22
DESCRIPTION->Variance calculation with dynamic arrays
Input->Enter the no.of elements : 10

Enter the 10 elements:
[0] -> 9
[1] -> 12
[2] -> 15
[3] -> 18
[4] -> 20
[5] -> 22
[6] -> 23
[7] -> 24
[8] -> 26
[9] -> 31
Output->Variance is 40.000000
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
   int i,n;
   float std_dev,sum=0,sumsqr=0,mean,value,variance=0.0;
   printf("Enter the no.of elements :");
   scanf("%d",&n);
   int *a=malloc(sizeof(int)*n);   //dynamic memeory allocation using maaloc
   printf("\nEnter the 10 elements:");
   for(i = 0;i < n; i++)   //input of numbers
   {
      printf("\n[%d] -> : ",i);
      scanf("%d",&a[i]);
      sum = sum + a[i];
   }
   mean = sum / n; //calaulating mean
   sumsqr = 0;
   for(i = 0; i < n; i++)
   {
     value = a[i] - mean;
     sumsqr = sumsqr + value * value;  //calculating square root
    }
     variance = sumsqr / n;   //calculating variance
     std_dev=sqrt(variance);
     //printf("\nMean of %d numbers = %f\n",n,mean);
     printf("\nVariance is %f\n",variance);
     //printf("\nStandard deviation of %d numbers = %f\n",n,std_dev);
     return 0;
}