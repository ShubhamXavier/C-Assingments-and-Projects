/*
NAME-> Shubham Singh
DATE-> 7-7-22
DESCRIPTION->WAP to reverse the given string using recursive method
Input->Enter the number : Enter a string : Hello World
Output->Reverse string is : dlroW olleH
*/


#include <stdio.h>

void reverse_recursive(char *str, int ind, int len);

int main()
{
    char str[30];
    
    
    printf("Enter any string : ");
    scanf("%[^\n]", str);
    
     reverse_recursive(str, 0, strlen(str)-1);
    
    printf("Reversed string is %s\n", str);
}

void reverse_recursive(char *str, int ind, int len)
{
     char ch;

   if (ind >= len) //condition to end recursiin call
      return;

        ch = *(str + ind);  //swapping
      *(str + ind) = *(str + len);
      *(str + len) = ch;

   reverse_recursive(str, ++ind, --len); //recursion call
}

